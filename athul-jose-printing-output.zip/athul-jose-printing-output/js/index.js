//Task 1
/*
Declare three variables, a and b and c.

If a has value 3, b has value 5, and c doesn't have a value, alert the following expressions ( one after another ). Alert popup box has to show the following content for each expression (concatenate everything in one long expression using "\n" to make new lines):

a + b
a - b
a * b
a / b
a % b
a += b
a -= b
a *= b
a /= b
a %= b
a == b
a != b
a > b
a < b
!a && !c 
!a || !c 
*/

let a = 3;
let b = 5;
let c

let printingoutput = `let a = 3; \nlet b = 5; \nlet c;\n----------- \n `;
printingoutput += `\na + b = ${ a + b }`;
printingoutput += `\na - b = ${ a - b }`;
printingoutput += `\na * b = ${ a * b }`;
printingoutput += `\na / b = ${ a / b }`;
printingoutput += `\na % b = ${ a % b }`;
printingoutput += `\na += b = ${ a += b }`;
printingoutput += `\na -= b = ${ a -= b }`;
printingoutput += `\na *= b = ${ a *= b }`;
printingoutput += `\na /= b = ${ a /= b }`;
printingoutput += `\na %= b = ${ a %= b }`;
printingoutput += `\na == b = ${ a == b }`;
printingoutput += `\na != b = ${ a != b }`;
printingoutput += `\na > b = ${ a > b }`;
printingoutput += `\na < b = ${ a < b }`;
printingoutput += `\n!a && !c = ${ !a && !c }`;
printingoutput += `\n!a || !c = ${ !a || !c }`;

alert(printingoutput);


//Task 2
/*Create the expression concatenating variables first_name, last_name, email and string literals needed to complete the sentence reading: "My name is Your-first-name Your-last-name. You can contact me at your-email@mail.com.";*/

let first_name = 'Athul';
let last_name  = 'Jose';
let email = 'jose0206@algonquinlive.com';

let output= `My name is ${first_name} ${last_name}.You can contact me at ${email}.`;
console.log(output);



